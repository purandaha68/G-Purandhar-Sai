package com.capgemini.lesson3.iteration;

public class DoWhileEg {

	public static void main(String[] args) {
		int i=0;
		do
		{
	        System.out.println(i + " ");
	   
	        i++;
	    }while(i<10);
	}
	
}
