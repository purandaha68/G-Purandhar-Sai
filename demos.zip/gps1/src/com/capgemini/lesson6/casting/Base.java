package com.capgemini.lesson6.casting;

public class Base {

	public Base()
	{
		System.out.println("Constructor in base class");
	}
	
	public void methodX()
	{
		System.out.println("X method in base class");
	}
}
