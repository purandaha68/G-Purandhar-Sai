package gps1;

public class Helloworld {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a,b,c,x;
		a=1;b=2;c=3;
		System.out.println(  a + b + c);

	}

}
