package com.capgemini.exception;

public class CapStoreException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
