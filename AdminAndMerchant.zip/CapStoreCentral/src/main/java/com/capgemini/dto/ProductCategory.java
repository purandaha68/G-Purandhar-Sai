package com.capgemini.dto;

public enum ProductCategory {

	BOOKS,
	ElECTRONICS,
	FASHION,
	HOME_and_FURNiSHINING,
	Personal_Car,
	Sports,
	Others
}
